import { verifyCheckoutSession } from '../../src/lib/biddingSession';

/**
 * Netlify Serverless Function: verify-checkout
 * Validates session and marks bid as paid
 */
export const handler = async (event: any) => {
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 204,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'GET, OPTIONS',
      },
      body: '',
    };
  }

  const q = event.queryStringParameters || {};
  const sessionId = q.session_id || q.sessionId;

  if (!sessionId) {
    return {
      statusCode: 400,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({ success: false, error: 'session_id query parameter is required' }),
    };
  }

  const fallbackData = {
    bidId: q.bid_id || q.bidId,
    user_name: q.u || q.user_name || q.name,
    handle: q.h || q.handle,
    amount: q.a ? Number(q.a) : (q.amount ? Number(q.amount) : undefined),
    category: q.c || q.category,
    profile_url: q.p || q.profile_url || q.product_url,
    message: q.m || q.message || q.msg,
    platform: q.plat || q.platform,
  };

  try {
    const result = await verifyCheckoutSession(sessionId, fallbackData);
    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify(result),
    };
  } catch (err: any) {
    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({ success: false, error: err?.message || 'Server error verifying session' }),
    };
  }
};
