import { createClient } from '@supabase/supabase-js';
import fs from 'fs';
import path from 'path';

export interface CheckoutRequestPayload {
  amount: number;
  profile_url: string;
  message?: string;
  category?: string;
  payment_method?: string;
  user_name?: string;
  handle?: string;
  platform?: string;
  origin?: string;
}

export interface CheckoutResponseData {
  success: boolean;
  checkout_url?: string;
  payment_url?: string;
  session_id?: string;
  bid_id?: string;
  provider?: string;
  mode?: 'free' | 'sponsored';
  error?: string;
  details?: Record<string, unknown>;
}

// In-memory registry of sessions for immediate retrieval & confirmation
export interface StoredSession {
  sessionId: string;
  bidId: string;
  amount: number;
  profile_url: string;
  message: string;
  category: string;
  payment_method: string;
  user_name: string;
  handle: string;
  platform: string;
  status: 'pending' | 'paid' | 'cancelled' | 'failed' | 'refunded';
  createdAt: string;
  paidAt?: string;
  updatedAt?: string;
}

const isNodeEnv = typeof process !== 'undefined' && Boolean(process.versions?.node);

function getPaidBidsFilePath(): string | null {
  if (!isNodeEnv) return null;
  try {
    const dataDir = path.resolve(process.cwd(), 'data');
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    return path.join(dataDir, 'paid_bids.json');
  } catch {
    return null;
  }
}

function loadPersistedPaidBids(): StoredSession[] {
  const filePath = getPaidBidsFilePath();
  if (!filePath) return [];
  try {
    if (fs.existsSync(filePath)) {
      const content = fs.readFileSync(filePath, 'utf8');
      const parsed = JSON.parse(content);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch {}
  return [];
}

export function savePersistedPaidBids(bids: StoredSession[]): void {
  const filePath = getPaidBidsFilePath();
  if (!filePath) return;
  try {
    fs.writeFileSync(filePath, JSON.stringify(bids, null, 2), 'utf8');
  } catch {}
}

const sessionStore = new Map<string, StoredSession>();
const paidBidsStore: StoredSession[] = loadPersistedPaidBids();

const DEFAULT_SUPABASE_URL = 'https://gpsknibtnwkudibkbkvk.supabase.co';
const DEFAULT_SUPABASE_ANON_KEY = 'sbp_4bc0a49852230623a31c6298fa204e5d4eaee1e7';

export function getSupabaseCredentials() {
  const url =
    (typeof process !== 'undefined' && (process.env.VITE_SUPABASE_URL || process.env.SUPABASE_URL)) ||
    (typeof import.meta !== 'undefined' && (import.meta as any)?.env?.VITE_SUPABASE_URL) ||
    DEFAULT_SUPABASE_URL;

  const key =
    (typeof process !== 'undefined' && (process.env.VITE_SUPABASE_ANON_KEY || process.env.SUPABASE_ANON_KEY)) ||
    (typeof import.meta !== 'undefined' && (import.meta as any)?.env?.VITE_SUPABASE_ANON_KEY) ||
    DEFAULT_SUPABASE_ANON_KEY;

  return { url, key };
}

let serverSupabaseClient: any = null;

export function getServerSupabaseClient() {
  if (serverSupabaseClient) return serverSupabaseClient;
  const { url, key } = getSupabaseCredentials();
  if (!url || !key) return null;
  try {
    serverSupabaseClient = createClient(url, key, {
      auth: { persistSession: false },
    });
    return serverSupabaseClient;
  } catch {
    return null;
  }
}

/**
 * Automatically records a confirmed bid directly into the Supabase leaderboard_bids table
 */
export async function recordPaidBidToSupabase(session: StoredSession): Promise<boolean> {
  const client = getServerSupabaseClient();
  if (!client) return false;

  const bidRecord = {
    id: session.bidId,
    user_name: session.user_name || 'Anonymous Bidder',
    handle: session.handle || '@builder',
    platform: session.platform || 'website',
    message: session.message || '',
    amount: Number(session.amount) || 1,
    category: session.category || 'Technology & AI',
    product_url: session.profile_url,
    created_at: session.paidAt || session.createdAt || new Date().toISOString(),
    clicks: 0,
  };

  try {
    let { error } = await client.from('leaderboard_bids').insert([bidRecord]);

    if (error && (error.code === 'PGRST204' || error.message?.includes('column') || error.code === '42703')) {
      const fallbackPayload = {
        id: bidRecord.id,
        user_name: bidRecord.user_name,
        handle: bidRecord.handle,
        platform: bidRecord.platform,
        message: `${bidRecord.product_url}${bidRecord.message ? ' | ' + bidRecord.message : ''}`,
        amount: bidRecord.amount,
        category: bidRecord.category,
        created_at: bidRecord.created_at,
      };
      const fallbackRes = await client.from('leaderboard_bids').insert([fallbackPayload]);
      error = fallbackRes.error;
    }

    if (error) {
      console.warn('[Supabase Sync Warning]:', error.message || error);
      return false;
    }
    return true;
  } catch (err: any) {
    console.warn('[Supabase Sync Error]:', err?.message || err);
    return false;
  }
}

/**
 * Creates a free sponsored bidding session
 */
export async function createCheckoutSession(
  payload: CheckoutRequestPayload,
  reqOrigin?: string
): Promise<CheckoutResponseData> {
  const {
    profile_url,
    message = '',
    category,
    payment_method = 'free_sponsor',
    user_name = '',
    handle = '',
    platform = 'website',
    origin,
  } = payload;

  const numericAmount = Number(payload.amount);
  if (!numericAmount || isNaN(numericAmount) || numericAmount <= 0) {
    return {
      success: false,
      error: 'Invalid bid amount. Must be a positive number of at least 1.',
    };
  }

  const cleanUrl = typeof profile_url === 'string' ? profile_url.trim() : '';
  if (!cleanUrl) {
    return {
      success: false,
      error: 'profile_url (destination website/link) is required.',
    };
  }

  const cleanCategory = (category && typeof category === 'string' && category.trim())
    ? category.trim()
    : 'Marketing';

  let effectiveAppUrl =
    (typeof window !== 'undefined' && window.location?.origin ? window.location.origin : '') ||
    origin ||
    (typeof process !== 'undefined' && (process.env.VITE_APP_URL || process.env.APP_URL || process.env.URL)) ||
    (typeof import.meta !== 'undefined' && (import.meta as any)?.env?.VITE_APP_URL) ||
    reqOrigin ||
    '';

  if (effectiveAppUrl.includes('localhost:3000')) {
    if (typeof window !== 'undefined' && window.location?.origin) {
      effectiveAppUrl = window.location.origin;
    } else if (typeof process !== 'undefined' && (process.env.VITE_APP_URL || process.env.APP_URL || process.env.URL)) {
      effectiveAppUrl = process.env.VITE_APP_URL || process.env.APP_URL || process.env.URL || '';
    }
  }

  effectiveAppUrl = effectiveAppUrl.replace(/\/+$/, '');

  const bidId = `bid-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
  const sessionId = `sess_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;

  const sessionData: StoredSession = {
    sessionId,
    bidId,
    amount: numericAmount,
    profile_url: cleanUrl,
    message: message.trim(),
    category: cleanCategory,
    payment_method,
    user_name: user_name.trim() || 'Anonymous Bidder',
    handle: handle.trim() || '@bidder',
    platform,
    status: 'paid',
    createdAt: new Date().toISOString(),
    paidAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  sessionStore.set(sessionId, sessionData);

  const existingIndex = paidBidsStore.findIndex((b) => b.sessionId === sessionId || b.bidId === bidId);
  if (existingIndex >= 0) {
    paidBidsStore[existingIndex] = sessionData;
  } else {
    paidBidsStore.unshift(sessionData);
  }
  savePersistedPaidBids(paidBidsStore);

  recordPaidBidToSupabase(sessionData).catch((err) => {
    console.warn('[Supabase Sync]:', err);
  });

  return {
    success: true,
    session_id: sessionId,
    bid_id: bidId,
    provider: 'free_sponsored',
    mode: 'sponsored' as any,
  };
}

/**
 * Verifies and marks a checkout session as paid
 */
export async function verifyCheckoutSession(
  sessionId?: string,
  fallbackData?: Partial<StoredSession>
): Promise<{ success: boolean; session?: StoredSession; error?: string }> {
  if (sessionId && sessionStore.has(sessionId)) {
    const session = sessionStore.get(sessionId)!;
    session.status = 'paid';
    session.paidAt = new Date().toISOString();
    session.updatedAt = new Date().toISOString();

    const existingIdx = paidBidsStore.findIndex((b) => b.sessionId === sessionId);
    if (existingIdx >= 0) {
      paidBidsStore[existingIdx] = session;
    } else {
      paidBidsStore.unshift(session);
    }
    savePersistedPaidBids(paidBidsStore);
    recordPaidBidToSupabase(session).catch(() => {});

    return { success: true, session };
  }

  if (fallbackData && fallbackData.amount) {
    const session: StoredSession = {
      sessionId: sessionId || fallbackData.sessionId || `sess_fb_${Date.now()}`,
      bidId: fallbackData.bidId || `bid-${Date.now()}`,
      amount: fallbackData.amount,
      profile_url: fallbackData.profile_url || 'https://bidzo.site',
      message: fallbackData.message || '',
      category: fallbackData.category || 'Technology & AI',
      payment_method: fallbackData.payment_method || 'free_sponsor',
      user_name: fallbackData.user_name || 'Anonymous Maker',
      handle: fallbackData.handle || '@builder',
      platform: fallbackData.platform || 'website',
      status: 'paid',
      createdAt: new Date().toISOString(),
      paidAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    sessionStore.set(session.sessionId, session);
    const existingIdx = paidBidsStore.findIndex((b) => b.sessionId === session.sessionId);
    if (existingIdx >= 0) {
      paidBidsStore[existingIdx] = session;
    } else {
      paidBidsStore.unshift(session);
    }
    savePersistedPaidBids(paidBidsStore);
    recordPaidBidToSupabase(session).catch(() => {});

    return { success: true, session };
  }

  return { success: false, error: 'Session not found and insufficient fallback data' };
}

/**
 * Directly records and confirms a paid/free bid into session store, disk, and Supabase
 */
export async function recordPaidBidDirectly(data: Partial<StoredSession>): Promise<StoredSession> {
  const sessionId = data.sessionId || `sess_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
  const bidId = data.bidId || `bid-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
  const session: StoredSession = {
    sessionId,
    bidId,
    amount: Number(data.amount) || 1,
    profile_url: data.profile_url || 'https://bidzo.site',
    message: data.message || '',
    category: data.category || 'Technology & AI',
    payment_method: data.payment_method || 'free_sponsor',
    user_name: data.user_name || 'Anonymous Maker',
    handle: data.handle || '@builder',
    platform: data.platform || 'website',
    status: 'paid',
    createdAt: data.createdAt || new Date().toISOString(),
    paidAt: data.paidAt || new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  sessionStore.set(sessionId, session);
  const existingIdx = paidBidsStore.findIndex((b) => b.sessionId === sessionId || b.bidId === bidId);
  if (existingIdx >= 0) {
    paidBidsStore[existingIdx] = session;
  } else {
    paidBidsStore.unshift(session);
  }
  savePersistedPaidBids(paidBidsStore);

  recordPaidBidToSupabase(session).catch(() => {});

  return session;
}

/**
 * Returns all recent paid bids from store
 */
export function getPaidBidsFromStore() {
  return [...paidBidsStore];
}
