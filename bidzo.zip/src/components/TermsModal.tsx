import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  X,
  ShieldCheck,
  Flame,
  Scale,
  Ban,
  Globe,
  CheckCircle2,
} from 'lucide-react';

interface TermsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const TermsModal: React.FC<TermsModalProps> = ({ isOpen, onClose }) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 font-sans">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.15 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/45 backdrop-blur-xs transform-gpu"
          />

          {/* Compact Dialog Window */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 8 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 8 }}
            transition={{ type: 'spring', duration: 0.22, bounce: 0 }}
            className="relative z-10 w-full max-w-lg max-h-[90vh] overflow-y-auto rounded-2xl border border-slate-200 bg-white p-5 shadow-xl sm:p-6 text-slate-800 transform-gpu will-change-transform"
          >
            {/* Close Button */}
            <button
              onClick={onClose}
              className="absolute right-4 top-4 rounded-full p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-800 transition-colors"
              aria-label="Close Terms modal"
            >
              <X className="h-4 w-4" />
            </button>

            {/* Header */}
            <div className="mb-4">
              <div className="inline-flex items-center gap-1.5 rounded-full border border-blue-200 bg-blue-50 px-2.5 py-0.5 text-[11px] font-semibold text-blue-600">
                <Scale className="h-3 w-3" />
                <span>Legal &amp; Platform Policy</span>
              </div>
              <h3 className="mt-1.5 font-heading text-xl font-bold tracking-tight text-slate-900">
                Terms of Service &amp; Fair Play Policy
              </h3>
              <p className="mt-0.5 text-xs text-slate-500">
                Last updated: November 2026 &bull; Rules governing dynamic ranking, free ad-sponsored bidding, and moderation on Bidzo.
              </p>
            </div>

            <div className="space-y-3.5 text-xs leading-relaxed text-slate-600">
              {/* Rule 1: Dynamic Ranking Policy */}
              <div className="rounded-xl border border-slate-200 bg-slate-50/70 p-3.5 space-y-2">
                <div className="flex items-center gap-2">
                  <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-lg bg-blue-50 border border-blue-200 text-blue-600">
                    <Flame className="h-3.5 w-3.5" />
                  </div>
                  <h4 className="font-heading font-bold text-slate-900 text-xs">
                    1. Dynamic Bid &amp; Ranking Policy
                  </h4>
                </div>
                <div className="space-y-1.5 pl-8 text-[11.5px] text-slate-600">
                  <p>
                    <strong className="text-slate-900">Bid-Driven Placement:</strong> Rank positions on the Bidzo leaderboard are strictly determined by total bid counts / points earned through verified rewarded sponsor interactions.
                  </p>
                  <p>
                    <strong className="text-slate-900">Real-Time Reordering:</strong> Entries with higher bid counts dynamically outrank lower entries in real-time. Rankings re-sort immediately upon confirmation.
                  </p>
                  <p>
                    <strong className="text-slate-900">No Permanent Rank Guarantee:</strong> Placing a bid establishes your position at that moment, but does <em>not</em> guarantee a permanent spot. Other creators or brands may outbid your spot with higher bid counts at any time, automatically shifting your listing to the next applicable rank.
                  </p>
                </div>
              </div>

              {/* Rule 2: 100% Free Ad-Sponsored Bidding */}
              <div className="rounded-xl border border-slate-200 bg-slate-50/70 p-3.5 space-y-2">
                <div className="flex items-center gap-2">
                  <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-600">
                    <ShieldCheck className="h-3.5 w-3.5" />
                  </div>
                  <h4 className="font-heading font-bold text-slate-900 text-xs">
                    2. 100% Free Ad-Sponsored Bidding &amp; Fair Play
                  </h4>
                </div>
                <div className="space-y-1.5 pl-8 text-[11.5px] text-slate-600">
                  <p>
                    <strong className="text-slate-900">Zero Fees &amp; No Payments:</strong> Bidding on Bidzo is completely free of charge. No payment gateways, fees, credit cards, or financial transactions are ever required or processed.
                  </p>
                  <p>
                    <strong className="text-slate-900">Rewarded Ad Verification:</strong> Free bids are verified and published immediately after completing a single 5-second partner sponsor showcase interaction.
                  </p>
                  <p>
                    <strong className="text-slate-900">Anti-Bot &amp; Fair Use:</strong> Automated scripts, click-spamming, or artificial manipulation of bid counts or outbound click metrics are strictly prohibited and may result in immediate removal.
                  </p>
                </div>
              </div>

              {/* Rule 3: Content Guidelines & Moderation */}
              <div className="rounded-xl border border-slate-200 bg-slate-50/70 p-3.5 space-y-2">
                <div className="flex items-center gap-2">
                  <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-lg bg-rose-50 border border-rose-200 text-rose-600">
                    <Ban className="h-3.5 w-3.5" />
                  </div>
                  <h4 className="font-heading font-bold text-slate-900 text-xs">
                    3. Content Guidelines &amp; Moderation
                  </h4>
                </div>
                <div className="space-y-1.5 pl-8 text-[11.5px] text-slate-600">
                  <p>
                    <strong className="text-slate-900">Prohibited Material:</strong> Submitted website URLs, social handles, brand names, logos, and pitch descriptions must not contain illegal content, hate speech, adult/NSFW material, malware, phishing links, deceptive scams, or impersonation.
                  </p>
                  <p>
                    <strong className="text-slate-900">Platform Discretion:</strong> Bidzo reserves the right to review, moderate, hide, or remove any non-compliant listing or deceptive domain at any time without prior notice.
                  </p>
                </div>
              </div>

              {/* Rule 4: Third-Party Links & Disclaimers */}
              <div className="rounded-xl border border-slate-200 bg-slate-50/70 p-3.5 space-y-2">
                <div className="flex items-center gap-2">
                  <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-lg bg-slate-100 border border-slate-200 text-slate-700">
                    <Globe className="h-3.5 w-3.5" />
                  </div>
                  <h4 className="font-heading font-bold text-slate-900 text-xs">
                    4. External Links &amp; Limitation of Liability
                  </h4>
                </div>
                <div className="space-y-1.5 pl-8 text-[11.5px] text-slate-600">
                  <p>
                    <strong className="text-slate-900">Third-Party Destinations:</strong> Bidzo acts as an open discovery board indexing user-submitted social profiles, creator channels, and websites. We do not endorse or assume liability for external third-party websites or partner sponsor pages.
                  </p>
                  <p>
                    <strong className="text-slate-900">Service Availability:</strong> The platform is provided &ldquo;as is&rdquo; without warranties of uninterrupted uptime or guaranteed referral traffic volume.
                  </p>
                </div>
              </div>

              {/* Summary note */}
              <div className="flex items-start gap-2 rounded-xl border border-slate-200 bg-slate-50 p-3 text-[11px] text-slate-600">
                <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-600 mt-0.5" />
                <span>
                  For assistance, listing updates, or content takedown requests, contact the team directly at{' '}
                  <a href="mailto:contact.bidzo@gmail.com" className="font-semibold text-blue-600 hover:underline">
                    contact.bidzo@gmail.com
                  </a>
                  .
                </span>
              </div>
            </div>

            {/* Bottom Action */}
            <div className="mt-5 flex justify-end">
              <button
                type="button"
                onClick={onClose}
                className="w-full sm:w-auto px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold shadow-xs transition-colors"
              >
                I Understand &amp; Agree
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

export default TermsModal;
