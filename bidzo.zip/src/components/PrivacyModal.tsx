import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, ShieldCheck, Lock, Eye, Database, Globe, CheckCircle2 } from 'lucide-react';

interface PrivacyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PrivacyModal: React.FC<PrivacyModalProps> = ({ isOpen, onClose }) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 font-sans">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.15 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/45 backdrop-blur-xs transform-gpu"
          />

          {/* Dialog Window */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 8 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 8 }}
            transition={{ type: 'spring', duration: 0.22, bounce: 0 }}
            className="relative z-10 w-full max-w-lg max-h-[88vh] overflow-y-auto rounded-2xl border border-slate-200 bg-white p-5 shadow-xl sm:p-6 text-slate-800 transform-gpu will-change-transform"
          >
            {/* Close Button */}
            <button
              onClick={onClose}
              className="absolute right-4 top-4 rounded-full p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-800 transition-colors"
              aria-label="Close Privacy modal"
            >
              <X className="h-4 w-4" />
            </button>

            {/* Header */}
            <div className="mb-4">
              <div className="inline-flex items-center gap-1.5 rounded-full border border-blue-200 bg-blue-50 px-2.5 py-0.5 text-[11px] font-semibold text-blue-600">
                <ShieldCheck className="h-3 w-3" />
                <span>Privacy &amp; Data Transparency</span>
              </div>
              <h3 className="mt-1.5 font-heading text-xl font-bold tracking-tight text-slate-900">
                Bidzo Privacy Policy
              </h3>
              <p className="mt-0.5 text-xs text-slate-500">
                Last updated: November 2026 &bull; Official contact: contact.bidzo@gmail.com
              </p>
            </div>

            {/* Content Sections */}
            <div className="space-y-3.5 text-xs leading-relaxed text-slate-600">
              <section className="rounded-xl border border-slate-100 bg-slate-50/80 p-3.5">
                <h4 className="font-heading text-xs font-bold text-slate-900 flex items-center gap-1.5 mb-1">
                  <Database className="h-3.5 w-3.5 text-blue-600" />
                  1. Public Listing Information
                </h4>
                <p>
                  When you place a free bid on Bidzo, your submitted destination URL, brand or creator name, social handle (such as TikTok, Instagram, YouTube, Snapchat, or X), short pitch, category, and total bid count become publicly visible on the live leaderboard. Do not include private or sensitive personal details in your listing.
                </p>
              </section>

              <section className="rounded-xl border border-slate-100 bg-slate-50/80 p-3.5">
                <h4 className="font-heading text-xs font-bold text-slate-900 flex items-center gap-1.5 mb-1">
                  <Lock className="h-3.5 w-3.5 text-blue-600" />
                  2. Zero Financial or Payment Data Collected
                </h4>
                <p>
                  Bidzo does not collect, process, or store credit card numbers, banking details, or payment credentials. All leaderboard placements are 100% free via interactive partner sponsor showcases.
                </p>
              </section>

              <section className="rounded-xl border border-slate-100 bg-slate-50/80 p-3.5">
                <h4 className="font-heading text-xs font-bold text-slate-900 flex items-center gap-1.5 mb-1">
                  <Eye className="h-3.5 w-3.5 text-blue-600" />
                  3. Click Metrics &amp; Local Browser Storage
                </h4>
                <p>
                  We record aggregate outbound click counts on ranked links to show engagement metrics on the leaderboard. Your browser&rsquo;s local storage may also be used to preserve session state, real-time leaderboard sync, and submission convenience. We do not sell personal data or deploy invasive cross-site tracking cookies.
                </p>
              </section>

              <section className="rounded-xl border border-slate-100 bg-slate-50/80 p-3.5">
                <h4 className="font-heading text-xs font-bold text-slate-900 flex items-center gap-1.5 mb-1">
                  <Globe className="h-3.5 w-3.5 text-blue-600" />
                  4. Third-Party Sites &amp; Sponsor Links
                </h4>
                <p>
                  Clicking on ranked creator profiles, product URLs, or rewarded sponsor links will direct you to external third-party websites, which operate under their own independent privacy policies and terms.
                </p>
              </section>

              <section className="rounded-xl border border-slate-100 bg-slate-50/80 p-3.5">
                <h4 className="font-heading text-xs font-bold text-slate-900 flex items-center gap-1.5 mb-1">
                  <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600" />
                  5. Updates, Deletion &amp; Contact Requests
                </h4>
                <p>
                  If you would like to update a destination URL, verify ownership, or request removal of a public listing, please email us directly at{' '}
                  <a href="mailto:contact.bidzo@gmail.com" className="font-semibold text-blue-600 hover:underline">
                    contact.bidzo@gmail.com
                  </a>
                  .
                </p>
              </section>
            </div>

            {/* Footer Action */}
            <div className="mt-5 pt-3 border-t border-slate-100 flex justify-end">
              <button
                type="button"
                onClick={onClose}
                className="rounded-xl bg-slate-900 px-4 py-2 text-xs font-semibold text-white hover:bg-slate-800 transition-colors shadow-2xs"
              >
                Understood &amp; Close
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

export default PrivacyModal;
