import React, { useState, useEffect } from 'react';
import {
  TrendingUp,
  Clock,
  Sparkles,
  ArrowRight,
  Crown,
} from 'lucide-react';
import { Category, TimeFilter, BidEntry } from '../types';
import { CATEGORIES } from './ui/CategoryConfig';
import { CustomDropdown } from './ui/CustomDropdown';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';

interface HeroSectionProps {
  timeFilter: TimeFilter;
  onTimeFilterChange: (filter: TimeFilter) => void;
  topBidAmount: number;
  topBidderName?: string;
  activeCategory?: string;
  onClaimRank: (initialData: {
    amount: number;
    target: string;
    category: Category;
  }) => void;
  bids: BidEntry[];
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  timeFilter,
  onTimeFilterChange,
  topBidAmount,
  topBidderName,
  activeCategory = 'All',
  onClaimRank,
  bids,
}) => {
  const [heroRef, isHeroVisible] = useIntersectionObserver();
  const [selectedCategory, setSelectedCategory] = useState<Category>(
    activeCategory && activeCategory !== 'All' && activeCategory !== 'Explore'
      ? (activeCategory as Category)
      : 'Marketing'
  );

  // Sync selectedCategory when activeCategory changes from outside
  useEffect(() => {
    if (activeCategory && activeCategory !== 'All' && activeCategory !== 'Explore') {
      setSelectedCategory(activeCategory as Category);
    }
  }, [activeCategory]);

  // Determine current active category
  const currentCategory = selectedCategory;

  // 1. Dynamic Base Bid Logic: Check the highest bid in the database for the active category
  const categoryBids = React.useMemo(() => {
    if (currentCategory && currentCategory !== 'All' && currentCategory !== 'Explore') {
      return bids.filter(
        (b) => b.category.toLowerCase() === currentCategory.toLowerCase()
      );
    }
    return bids;
  }, [bids, currentCategory]);

  // Check highest bid in database for active category (0 if no bids exist / empty state)
  const categoryHighestBid = React.useMemo(() => {
    if (categoryBids.length === 0) return 0;
    return Math.max(...categoryBids.map((b) => b.amount));
  }, [categoryBids]);

  const categoryTopBidder = React.useMemo(() => {
    if (categoryBids.length === 0) return undefined;
    return categoryBids.reduce(
      (prev, curr) => (curr.amount > prev.amount ? curr : prev),
      categoryBids[0]
    );
  }, [categoryBids]);

  // IF no bids exist (0 total / empty state): Set default "Claim #1" bid to 1 Bid.
  // IF bids exist (highest bid = X): Set default "Claim #1" bid dynamically to (X + 1) Bids.
  const defaultClaimPrice = categoryHighestBid > 0 ? categoryHighestBid + 1 : 1;

  const [bidAmount, setBidAmount] = useState<number>(defaultClaimPrice);
  const [productTarget, setProductTarget] = useState<string>('');
  const [inputError, setInputError] = useState<string>('');

  // Sync default bid price whenever category or highest bid in category changes
  useEffect(() => {
    setBidAmount(categoryHighestBid > 0 ? categoryHighestBid + 1 : 1);
  }, [categoryHighestBid, currentCategory]);

  const calculateTargetRank = (amount: number) => {
    const higherCount = categoryBids.filter((b) => b.amount >= amount).length;
    return higherCount + 1;
  };

  const prospectiveRank = calculateTargetRank(bidAmount);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!productTarget.trim()) {
      setInputError('Please enter your product URL or @handle');
      return;
    }
    setInputError('');
    onClaimRank({
      amount: bidAmount,
      target: productTarget.trim(),
      category: selectedCategory,
    });
  };

  return (
    <div ref={heroRef} className={`relative z-40 mx-auto w-full max-w-5xl px-4 py-4 sm:py-6 scroll-fade-in ${isHeroVisible ? 'is-visible' : ''}`}>
      {/* Background soft electric blue highlight glow */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -top-12 left-1/2 -z-10 h-72 w-full max-w-2xl -translate-x-1/2 bg-gradient-to-b from-blue-50/80 via-blue-50/30 to-transparent blur-3xl transform-gpu"
      />

      <div className="flex flex-col items-center text-center">
        {/* Toggle pill switch: "All-time" vs "Today" */}
        <div className="mb-4 inline-flex items-center rounded-full border border-slate-200 bg-white p-1 font-sans shadow-2xs">
          <button
            onClick={() => onTimeFilterChange('all-time')}
            className={`flex items-center gap-1.5 rounded-full px-3.5 py-1 text-xs font-semibold transition-all duration-150 transform-gpu ${
              timeFilter === 'all-time'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <TrendingUp className="h-3.5 w-3.5" />
            <span>All-time</span>
          </button>
          <button
            onClick={() => onTimeFilterChange('today')}
            className={`flex items-center gap-1.5 rounded-full px-3.5 py-1 text-xs font-semibold transition-all duration-150 transform-gpu ${
              timeFilter === 'today'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Clock className="h-3.5 w-3.5" />
            <span>Today</span>
          </button>
        </div>

        {/* Headline: Claim #1 Free Spot */}
        <div className="relative mb-2.5 flex flex-wrap items-center justify-center gap-x-2.5 gap-y-1.5">
          <h1 className="font-heading text-3xl font-black tracking-tight text-slate-900 sm:text-4xl lg:text-[42px]">
            Claim <span className="text-blue-600">#1</span> Free Spot
          </h1>
        </div>

        {/* Predictive Rank Indicator */}
        <div className="mb-5 flex flex-wrap items-center justify-center gap-1.5 text-xs font-sans text-slate-600">
          <div className="inline-flex items-center gap-1.5 font-medium">
            {prospectiveRank === 1 ? (
              <>
                <Crown className="h-3.5 w-3.5 text-amber-500" />
                <span className="font-semibold text-emerald-600">
                  Guarantees #1 Spot
                </span>
                <span className="text-slate-500">
                  {categoryTopBidder && categoryHighestBid > 0
                    ? `(beats ${categoryTopBidder.user_name} with ${categoryHighestBid} ${categoryHighestBid === 1 ? 'Bid' : 'Bids'})`
                    : '(first maker to claim #1!)'}
                </span>
              </>
            ) : (
              <>
                <Sparkles className="h-3.5 w-3.5 text-blue-600" />
                <span className="text-slate-900">
                  Secures Rank #{prospectiveRank} on leaderboard
                </span>
              </>
            )}
          </div>
        </div>

        {/* Inline interactive submission form */}
        <form
          onSubmit={handleSubmit}
          className="relative z-50 w-full max-w-2xl font-sans"
        >
          <div className="premium-glow-box rounded-2xl p-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-2 relative z-50">
            {/* a) Text Input: "Your product URL or @handle" */}
            <div className="relative flex-1 min-w-0">
              <input
                type="text"
                placeholder="Your URL or @handle"
                value={productTarget}
                onChange={(e) => {
                  setProductTarget(e.target.value);
                  if (inputError) setInputError('');
                }}
                className="w-full rounded-xl outline-none border-none bg-transparent px-3.5 py-2.5 text-xs sm:text-sm text-slate-900 placeholder-slate-400 transition-colors"
              />
            </div>

            {/* b) Custom Dropdown: "Choose a category" */}
            <CustomDropdown
              selected={selectedCategory}
              onChange={(cat) => setSelectedCategory(cat)}
              options={CATEGORIES.filter((c) => c !== 'All' && c !== 'Explore')}
              className="relative z-50 w-full sm:w-44 shrink-0"
            />

            {/* c) Primary CTA: Prominent rounded blue "Claim rank" button */}
            <button
              type="submit"
              className="flex items-center justify-center gap-1.5 rounded-xl bg-blue-600 px-5 py-2.5 text-xs sm:text-sm font-semibold text-white shadow-xs transition-all duration-150 hover:bg-blue-700 active:scale-95 transform-gpu shrink-0 cursor-pointer"
            >
              <span>Claim rank</span>
              <ArrowRight className="h-4 w-4" />
            </button>
          </div>

          {inputError && (
            <p className="mt-2 text-left px-3 text-xs font-medium text-rose-500">
              {inputError}
            </p>
          )}
        </form>

        {/* Micro-subtext */}
        <p className="mt-2.5 text-[11px] sm:text-xs text-slate-500 font-sans">
          Instant placement &bull; Real-time click tracking &bull; High-intent discovery &bull; Rank #1 instantly on Bidzo
        </p>
      </div>
    </div>
  );
};

export default HeroSection;
