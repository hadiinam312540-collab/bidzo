import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { motion, AnimatePresence } from 'framer-motion';
import {
  X,
  Crown,
  Sparkles,
  Check,
  ArrowRight,
  Plus,
  Minus,
  Zap,
  Loader2,
  ExternalLink,
  ShieldCheck,
  Clock,
  CheckCircle2,
} from 'lucide-react';
import { Category, Platform, BidEntry } from '../types';
import { CATEGORIES, CATEGORY_ICON_MAP } from './ui/CategoryConfig';
import { SPONSOR_ADS } from './RewardedAdModal';

interface BidModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmitBid: (bid: {
    user_name: string;
    handle: string;
    platform: Platform;
    message: string;
    amount: number;
    category: string;
    product_url: string;
  }) => Promise<void>;
  initialAmount?: number;
  initialTarget?: string;
  initialCategory?: Category;
  highestBid: number;
  bids: BidEntry[];
  onOpenTerms?: () => void;
}

export const BidModal: React.FC<BidModalProps> = ({
  isOpen,
  onClose,
  onSubmitBid,
  initialAmount,
  initialTarget = '',
  initialCategory = 'Marketing',
  highestBid,
  bids,
  onOpenTerms,
}) => {
  const [amount, setAmount] = useState<number>(
    initialAmount || (highestBid > 0 ? highestBid + 1 : 1)
  );
  const [userName, setUserName] = useState<string>('');
  const [productUrl, setProductUrl] = useState<string>(initialTarget);
  const [handle, setHandle] = useState<string>('');
  const [platform, setPlatform] = useState<Platform>('website');
  const [category, setCategory] = useState<Category>(initialCategory);
  const [message, setMessage] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [step, setStep] = useState<'details' | 'ad' | 'success'>('details');
  const [errorMsg, setErrorMsg] = useState<string>('');
  const [agreedToTerms, setAgreedToTerms] = useState<boolean>(true);

  // Rewarded ad countdown state
  const AD_DURATION = 5;
  const [adTimer, setAdTimer] = useState<number>(AD_DURATION);
  const [adFinished, setAdFinished] = useState<boolean>(false);
  const [adIndex, setAdIndex] = useState<number>(0);

  useEffect(() => {
    if (isOpen) {
      if (initialCategory) {
        setCategory(initialCategory);
      }
      if (initialAmount) {
        setAmount(initialAmount);
      } else {
        setAmount(highestBid > 0 ? highestBid + 1 : 1);
      }
      if (initialTarget) {
        const trimmed = initialTarget.trim();
        setProductUrl(trimmed);

        // Detect platform from handle or URL
        if (trimmed.startsWith('@')) {
          setHandle(trimmed);
          setUserName(trimmed.replace('@', ''));
          setPlatform('x');
        } else {
          const lower = trimmed.toLowerCase();
          if (lower.includes('tiktok.com')) setPlatform('tiktok');
          else if (lower.includes('instagram.com')) setPlatform('instagram');
          else if (lower.includes('youtube.com') || lower.includes('youtu.be')) setPlatform('youtube');
          else if (lower.includes('snapchat.com')) setPlatform('snapchat');
          else if (lower.includes('github.com')) setPlatform('github');
          else if (lower.includes('x.com') || lower.includes('twitter.com')) setPlatform('x');
          else setPlatform('website');

          try {
            const withProto = /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
            const parsed = new URL(withProto);
            const host = parsed.hostname.replace(/^www\./, '');
            if (host) {
              const rootName = host.split('.')[0];
              if (rootName) {
                setUserName(rootName.charAt(0).toUpperCase() + rootName.slice(1));
              }
            }
          } catch {
            // ignore
          }
        }
      }
      setStep('details');
      setErrorMsg('');
      setAgreedToTerms(true);
      setAdTimer(AD_DURATION);
      setAdFinished(false);
      setAdIndex(Math.floor(Math.random() * SPONSOR_ADS.length));
    }
  }, [isOpen, initialAmount, initialTarget, initialCategory, highestBid]);

  // Handle ad countdown when in 'ad' step
  useEffect(() => {
    if (step !== 'ad' || adFinished) return;

    if (adTimer <= 0) {
      setAdFinished(true);
      return;
    }

    const timer = setInterval(() => {
      setAdTimer((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          setAdFinished(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [step, adTimer, adFinished]);

  if (!isOpen) return null;

  const calculateRank = (amt: number) => {
    const higherCount = bids.filter((b) => b.amount >= amt).length;
    return higherCount + 1;
  };

  const predictedRank = calculateRank(amount);

  const handleAdjust = (delta: number) => {
    setAmount((prev) => Math.max(prev + delta, 1));
  };

  const handleStartRewardedAd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userName.trim()) {
      setErrorMsg('Please enter your product or brand name.');
      return;
    }
    if (!productUrl.trim()) {
      setErrorMsg('Please enter your destination product URL.');
      return;
    }
    if (amount <= 0) {
      setErrorMsg('Bid points must be at least 1.');
      return;
    }

    setErrorMsg('');
    setAdTimer(AD_DURATION);
    setAdFinished(false);
    setAdIndex(Math.floor(Math.random() * SPONSOR_ADS.length));
    setStep('ad');
  };

  const handlePublishFreeBid = async () => {
    setErrorMsg('');
    setIsSubmitting(true);
    try {
      let finalUrl = productUrl.trim();
      if (!finalUrl.startsWith('http://') && !finalUrl.startsWith('https://')) {
        finalUrl = `https://${finalUrl}`;
      }

      let finalHandle = handle.trim() || `@${userName.toLowerCase().replace(/\s+/g, '')}`;
      if (!finalHandle.startsWith('@') && platform !== 'website') {
        finalHandle = `@${finalHandle}`;
      }

      // Submit bid completely free of charge!
      await onSubmitBid({
        user_name: userName.trim(),
        handle: finalHandle,
        platform,
        message: message.trim() || 'Claimed position on Bidzo (Free Sponsor Bid)',
        amount,
        category,
        product_url: finalUrl,
      });

      // Celebration confetti
      confetti({
        particleCount: 140,
        spread: 80,
        origin: { y: 0.6 },
        colors: ['#2563EB', '#3B82F6', '#60A5FA', '#10B981', '#0F172A'],
      });

      setStep('success');
      setTimeout(() => {
        onClose();
      }, 2000);
    } catch (err: any) {
      setErrorMsg(err?.message || 'Failed to publish bid. Please try again.');
      setIsSubmitting(false);
    }
  };

  const currentSponsor = SPONSOR_ADS[adIndex] || SPONSOR_ADS[0];
  const progressPercent = Math.min(100, Math.round(((AD_DURATION - adTimer) / AD_DURATION) * 100));

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 font-sans">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.15 }}
            onClick={() => {
              if (step !== 'ad' || adFinished) {
                onClose();
              }
            }}
            className="fixed inset-0 bg-black/45 backdrop-blur-xs transform-gpu"
          />

          {/* Compact Dialog Window */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 8 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 8 }}
            transition={{ type: 'spring', duration: 0.22, bounce: 0 }}
            className="relative z-10 w-full max-w-md max-h-[92vh] overflow-y-auto rounded-2xl border border-slate-200 bg-white p-5 shadow-xl sm:p-6 text-slate-900 transform-gpu will-change-transform"
          >
            {/* Close Button */}
            <button
              onClick={onClose}
              className="absolute right-4 top-4 rounded-full p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-900 transition-colors"
            >
              <X className="h-4 w-4" />
            </button>

            {/* STEP 1: PRODUCT DETAILS & BID POINTS */}
            {step === 'details' && (
              <div>
                {/* Header */}
                <div className="mb-4">
                  <div className="inline-flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-2.5 py-0.5 text-[11px] font-semibold text-emerald-700">
                    <Sparkles className="h-3 w-3 text-emerald-600" />
                    <span>100% Free Sponsored Bidding</span>
                  </div>
                  <h3 className="mt-1.5 font-heading text-xl font-bold tracking-tight text-slate-900">
                    Claim Your Rank
                  </h3>
                  <p className="mt-0.5 text-xs text-slate-500">
                    Watch a quick 5-second sponsor showcase to place your product on the live leaderboard for free.
                  </p>
                </div>

                {errorMsg && (
                  <div className="mb-3 rounded-xl border border-rose-200 bg-rose-50 p-2.5 text-xs font-semibold text-rose-600">
                    {errorMsg}
                  </div>
                )}

                <form onSubmit={handleStartRewardedAd} className="space-y-3">
                  {/* Product Name */}
                  <div>
                    <label className="block text-[11px] font-medium uppercase tracking-wider text-slate-500">
                      Product / Brand Name *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. SuperAgent OS"
                      value={userName}
                      onChange={(e) => setUserName(e.target.value)}
                      className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs sm:text-sm text-slate-900 placeholder-slate-400 focus:border-blue-600 focus:outline-none focus:ring-1 focus:ring-blue-600"
                    />
                  </div>

                  {/* Product URL */}
                  <div>
                    <label className="block text-[11px] font-medium uppercase tracking-wider text-slate-500">
                      Destination URL *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="https://yourproduct.com"
                      value={productUrl}
                      onChange={(e) => setProductUrl(e.target.value)}
                      className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs sm:text-sm text-slate-900 placeholder-slate-400 focus:border-blue-600 focus:outline-none focus:ring-1 focus:ring-blue-600"
                    />
                  </div>

                  {/* Category & Platform row */}
                  <div className="grid grid-cols-2 gap-2.5">
                    <div>
                      <label className="block text-[11px] font-medium uppercase tracking-wider text-slate-500">
                        Category
                      </label>
                      <select
                        value={category}
                        onChange={(e) => setCategory(e.target.value as Category)}
                        className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-2.5 py-2 text-xs font-medium text-slate-900 focus:border-blue-600 focus:outline-none focus:ring-1 focus:ring-blue-600"
                      >
                        {CATEGORIES.filter((c: Category) => c !== 'All' && c !== 'Explore').map((cat: Category) => (
                          <option key={cat} value={cat} className="bg-white text-slate-900">
                            {cat}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-[11px] font-medium uppercase tracking-wider text-slate-500">
                        Platform
                      </label>
                      <select
                        value={platform}
                        onChange={(e) => setPlatform(e.target.value as Platform)}
                        className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-2.5 py-2 text-xs font-medium text-slate-900 focus:border-blue-600 focus:outline-none focus:ring-1 focus:ring-blue-600"
                      >
                        <option value="website" className="bg-white text-slate-900">Website</option>
                        <option value="x" className="bg-white text-slate-900">Twitter / X</option>
                        <option value="youtube" className="bg-white text-slate-900">YouTube</option>
                        <option value="tiktok" className="bg-white text-slate-900">TikTok</option>
                        <option value="instagram" className="bg-white text-slate-900">Instagram</option>
                        <option value="snapchat" className="bg-white text-slate-900">Snapchat</option>
                        <option value="github" className="bg-white text-slate-900">GitHub</option>
                      </select>
                    </div>
                  </div>

                  {/* Handle */}
                  <div>
                    <label className="block text-[11px] font-medium uppercase tracking-wider text-slate-500">
                      Handle or Creator Link
                    </label>
                    <input
                      type="text"
                      placeholder="@yourhandle"
                      value={handle}
                      onChange={(e) => setHandle(e.target.value)}
                      className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs sm:text-sm text-slate-900 placeholder-slate-400 focus:border-blue-600 focus:outline-none focus:ring-1 focus:ring-blue-600"
                    />
                  </div>

                  {/* Pitch snippet */}
                  <div>
                    <div className="flex justify-between items-center">
                      <label className="block text-[11px] font-medium uppercase tracking-wider text-slate-500">
                        Short Pitch / Snippet
                      </label>
                      <span className="text-[10px] text-slate-400">
                        {message.length}/120
                      </span>
                    </div>
                    <input
                      type="text"
                      maxLength={120}
                      placeholder="One sentence pitch (e.g. AI-powered code generator)"
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs sm:text-sm text-slate-900 placeholder-slate-400 focus:border-blue-600 focus:outline-none focus:ring-1 focus:ring-blue-600"
                    />
                  </div>

                  {/* Free Bid Points Stepper & Predicted Rank Box */}
                  <div className="rounded-xl border border-slate-200 bg-slate-50 p-3 space-y-2.5">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="text-xs font-semibold text-slate-900">
                            Rank Bid Score / Points
                          </span>
                          <span className="rounded-full bg-emerald-100 px-1.5 py-0.2 text-[9px] font-bold text-emerald-800">
                            100% Free
                          </span>
                        </div>
                        <div className="mt-0.5 flex items-center gap-1.5 text-xs text-slate-500">
                          {predictedRank === 1 ? (
                            <span className="font-semibold text-emerald-600 flex items-center gap-1">
                              <Crown className="h-3 w-3 text-amber-500" />
                              <span>Secures #1 Spot</span>
                            </span>
                          ) : (
                            <span>Secures Rank #{predictedRank}</span>
                          )}
                        </div>
                      </div>

                      {/* Stepper buttons & input */}
                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => handleAdjust(amount <= 5 ? -1 : -5)}
                          disabled={amount <= 1}
                          className="flex h-7 w-7 items-center justify-center rounded-lg border border-slate-200 bg-white text-slate-600 hover:bg-slate-100 hover:text-slate-900 active:scale-95 disabled:opacity-30 disabled:cursor-not-allowed transform-gpu"
                        >
                          <Minus className="h-3.5 w-3.5" />
                        </button>
                        <div className="flex items-center rounded-lg border border-slate-200 bg-white px-2.5 py-0.5 shadow-2xs">
                          <input
                            type="number"
                            min={1}
                            value={amount}
                            onChange={(e) => {
                              const val = parseInt(e.target.value, 10);
                              setAmount(isNaN(val) ? 1 : Math.max(1, val));
                            }}
                            className="w-12 text-center font-heading text-lg font-bold text-blue-600 tabular-nums focus:outline-none"
                          />
                          <span className="text-xs font-bold text-slate-500 ml-1">Bids</span>
                        </div>
                        <button
                          type="button"
                          onClick={() => handleAdjust(amount < 5 ? 1 : 5)}
                          className="flex h-7 w-7 items-center justify-center rounded-lg border border-slate-200 bg-white text-slate-600 hover:bg-slate-100 hover:text-slate-900 active:scale-95 transform-gpu"
                        >
                          <Plus className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </div>

                  </div>

                  {/* Free Sponsored Bid Explainer */}
                  <div className="rounded-xl border border-emerald-100 bg-emerald-50/40 p-2.5 text-xs text-emerald-800 flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-emerald-600 shrink-0" />
                    <span>
                      <strong>100% Free Placement:</strong> No fees or cards. Watch a 5s sponsor showcase to verify and unlock your live rank.
                    </span>
                  </div>

                  {/* Submit CTA */}
                  <button
                    type="submit"
                    className="w-full flex items-center justify-center gap-1.5 rounded-xl bg-blue-600 py-3 text-xs sm:text-sm font-semibold text-white shadow-xs hover:bg-blue-700 active:scale-95 transition-all transform-gpu cursor-pointer"
                  >
                    <Zap className="h-4 w-4" />
                    <span>Watch 5s Sponsor Ad &amp; Place Free Bid</span>
                    <ArrowRight className="h-4 w-4" />
                  </button>
                </form>
              </div>
            )}

            {/* STEP 2: REWARDED POPUP AD INTERACTION */}
            {step === 'ad' && (
              <div className="space-y-4">
                {/* Header with Countdown */}
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-blue-600 block">
                      Rewarded Sponsor Ad
                    </span>
                    <h4 className="font-heading text-lg font-bold text-slate-900">
                      Unlocking Free Placement
                    </h4>
                  </div>

                  {adFinished ? (
                    <div className="inline-flex items-center gap-1 rounded-full bg-emerald-100 px-2.5 py-1 text-xs font-bold text-emerald-800 shadow-2xs">
                      <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600" />
                      <span>Reward Unlocked!</span>
                    </div>
                  ) : (
                    <div className="inline-flex items-center gap-1 rounded-full border border-blue-200 bg-blue-50 px-2.5 py-1 text-xs font-mono font-bold text-blue-700">
                      <Clock className="h-3.5 w-3.5 text-blue-600 animate-spin" style={{ animationDuration: '3s' }} />
                      <span>{adTimer}s</span>
                    </div>
                  )}
                </div>

                {/* Progress Bar */}
                <div className="h-1.5 w-full rounded-full bg-slate-100 overflow-hidden">
                  <motion.div
                    className="h-full bg-blue-600"
                    initial={{ width: '0%' }}
                    animate={{ width: `${progressPercent}%` }}
                    transition={{ ease: 'linear', duration: 0.2 }}
                  />
                </div>

                {/* Sponsor Creative Card */}
                <div className="rounded-xl border border-slate-200 bg-gradient-to-br from-slate-50 via-white to-blue-50/20 p-4 space-y-3">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className="relative flex h-12 w-12 shrink-0 items-center justify-center rounded-xl border border-slate-200 bg-white p-2 shadow-2xs">
                        <img
                          src={currentSponsor.logoUrl}
                          alt={`${currentSponsor.name} logo`}
                          className="h-8 w-8 object-contain"
                        />
                        <div
                          title="Verified Partner"
                          className="absolute -bottom-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-blue-600 text-white shadow-2xs ring-2 ring-white"
                        >
                          <ShieldCheck className="h-2.5 w-2.5" />
                        </div>
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="font-heading text-base font-bold text-slate-900">
                            {currentSponsor.name}
                          </span>
                          <span className="rounded-md border border-slate-200 bg-white px-1.5 py-0.5 text-[9px] font-semibold text-slate-600">
                            {currentSponsor.category}
                          </span>
                        </div>
                        <p className="text-xs font-medium text-blue-600">
                          {currentSponsor.tagline}
                        </p>
                      </div>
                    </div>
                  </div>

                  <p className="text-xs text-slate-600 leading-relaxed">
                    {currentSponsor.description}
                  </p>

                  {/* Bullet features */}
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {currentSponsor.features.map((feat, idx) => (
                      <span
                        key={idx}
                        className="inline-flex items-center gap-1 rounded-md bg-white border border-slate-200 px-2 py-0.5 text-[10px] font-medium text-slate-700"
                      >
                        <CheckCircle2 className="h-2.5 w-2.5 text-emerald-600" />
                        <span>{feat}</span>
                      </span>
                    ))}
                  </div>

                  {/* Visit sponsor button */}
                  <div className="pt-1">
                    <a
                      href={currentSponsor.websiteUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      onClick={() => {
                        // Bonus: clicking sponsor unlocks reward immediately
                        setAdFinished(true);
                        setAdTimer(0);
                      }}
                      className="inline-flex items-center gap-1.5 text-xs font-semibold text-blue-600 hover:text-blue-700 hover:underline"
                    >
                      <span>{currentSponsor.callToAction}</span>
                      <ExternalLink className="h-3 w-3" />
                    </a>
                  </div>
                </div>

                {/* Target Confirmation Summary */}
                <div className="rounded-xl border border-slate-200 bg-slate-50 p-3 text-xs space-y-1">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Target Product:</span>
                    <span className="font-semibold text-slate-900">{userName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Destination:</span>
                    <span className="font-mono text-slate-700 truncate max-w-[200px]">{productUrl}</span>
                  </div>
                  <div className="flex justify-between border-t border-slate-200 pt-1 mt-1">
                    <span className="text-slate-500">Unlocked Rank:</span>
                    <span className="font-bold text-blue-600">Rank #{predictedRank} {predictedRank === 1 && '👑'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Cost:</span>
                    <span className="font-bold text-emerald-600">FREE (0 Fees &bull; 100% Free via Sponsor Ad)</span>
                  </div>
                </div>

                {/* Bottom Action Bar */}
                <div className="flex gap-2.5 pt-2">
                  <button
                    type="button"
                    onClick={() => {
                      setErrorMsg('');
                      setStep('details');
                    }}
                    className="flex-1 rounded-xl border border-slate-200 bg-white py-2.5 text-xs font-semibold text-slate-600 hover:bg-slate-50"
                  >
                    Back
                  </button>

                  <button
                    type="button"
                    disabled={!adFinished || isSubmitting}
                    onClick={handlePublishFreeBid}
                    className={`flex-[2] flex items-center justify-center gap-1.5 rounded-xl py-2.5 text-xs sm:text-sm font-bold transition-all shadow-xs transform-gpu ${
                      adFinished && !isSubmitting
                        ? 'bg-blue-600 text-white hover:bg-blue-700 cursor-pointer active:scale-95 shadow-blue-600/25 ring-2 ring-blue-500/20'
                        : 'bg-slate-200 text-slate-400 cursor-not-allowed opacity-75'
                    }`}
                  >
                    {isSubmitting ? (
                      <div className="flex items-center gap-1.5">
                        <Loader2 className="h-4 w-4 animate-spin" />
                        <span>Publishing to Leaderboard...</span>
                      </div>
                    ) : adFinished ? (
                      <>
                        <Zap className="h-4 w-4 fill-current" />
                        <span>Publish Free Bid Now</span>
                        <ArrowRight className="h-4 w-4" />
                      </>
                    ) : (
                      <>
                        <Clock className="h-4 w-4" />
                        <span>Unlocking in {adTimer}s...</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}

            {/* STEP 3: SUCCESS CELEBRATION */}
            {step === 'success' && (
              <div className="py-6 text-center">
                <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-emerald-50 text-emerald-600 border border-emerald-200">
                  <Check className="h-7 w-7 stroke-[3]" />
                </div>
                <h3 className="mt-3 font-heading text-xl font-bold text-slate-900">
                  Rank #{predictedRank} Claimed Free!
                </h3>
                <p className="mt-1 text-xs text-slate-500">
                  {userName} is now live on Bidzo with real-time click tracking enabled.
                </p>
                <div className="mt-4 inline-flex items-center gap-1.5 rounded-full bg-blue-50 border border-blue-200 px-3 py-1 text-xs font-semibold text-blue-700">
                  <Sparkles className="h-3.5 w-3.5 text-blue-600" />
                  <span>Recorded in Supabase &amp; Live in Real-time</span>
                </div>
              </div>
            )}
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

export default BidModal;
