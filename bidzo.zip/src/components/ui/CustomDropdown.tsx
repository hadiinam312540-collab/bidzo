import React, { useState, useRef, useEffect } from 'react';
import { ChevronDown, Check } from 'lucide-react';
import { Category } from '../../types';
import { CATEGORY_ICON_MAP } from './CategoryConfig';

interface CustomDropdownProps {
  selected: Category;
  onChange: (category: Category) => void;
  options: Category[];
  className?: string;
}

export const CustomDropdown: React.FC<CustomDropdownProps> = ({
  selected,
  onChange,
  options,
  className = '',
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isOpen]);

  const toggleDropdown = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsOpen((prev) => !prev);
  };

  return (
    <div className={`relative ${isOpen ? 'z-[9999]' : 'z-30'} ${className}`} ref={dropdownRef}>
      <button
        type="button"
        onClick={toggleDropdown}
        aria-expanded={isOpen}
        aria-haspopup="listbox"
        className="flex w-full items-center justify-between gap-2 rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-xs font-semibold text-slate-900 transition-colors hover:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20 cursor-pointer select-none"
      >
        <span className="flex items-center gap-2 font-heading truncate">
          {CATEGORY_ICON_MAP[selected as keyof typeof CATEGORY_ICON_MAP]}
          <span className="truncate">{selected}</span>
        </span>
        <ChevronDown className={`h-3.5 w-3.5 shrink-0 text-slate-400 transition-transform duration-150 ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {isOpen && (
        <div
          role="listbox"
          onClick={(e) => e.stopPropagation()}
          className="absolute top-full right-0 w-full min-w-[210px] z-[9999] bg-white border border-slate-200 rounded-xl shadow-xl max-h-60 overflow-y-auto mt-2 p-1.5 space-y-0.5"
        >
          {options.map((cat) => (
            <button
              key={cat}
              type="button"
              role="option"
              aria-selected={selected === cat}
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                onChange(cat);
                setIsOpen(false);
              }}
              className={`flex w-full items-center gap-2.5 rounded-xl px-3 py-2 text-xs font-medium transition-colors cursor-pointer ${
                selected === cat
                  ? 'bg-blue-600 text-white shadow-xs font-semibold'
                  : 'text-slate-700 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              <span className={selected === cat ? 'text-white' : 'text-slate-500'}>
                {CATEGORY_ICON_MAP[cat as keyof typeof CATEGORY_ICON_MAP]}
              </span>
              <span className="truncate">{cat}</span>
              {selected === cat && <Check className="h-3.5 w-3.5 ml-auto shrink-0" />}
            </button>
          ))}
        </div>
      )}
    </div>
  );
};
