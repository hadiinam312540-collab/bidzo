import React, { useState, useRef, useEffect } from 'react';
import { 
  ChevronDown, 
  Check, 
  Filter, 
  Compass, 
  X,
  Smartphone,
  MessageSquare,
  TrendingUp,
  Megaphone,
  Search,
  Zap,
  Bot,
  Code,
  Bitcoin,
  MoreHorizontal
} from 'lucide-react';
import { TikTokIcon, InstagramIcon, YouTubeIcon, SnapchatIcon } from './BrandIcons';
import { Category } from '../../types';

export const CATEGORY_ICON_MAP: Record<Category, React.ReactNode> = {
  All: <Filter className="h-4 w-4" />,
  TikTok: <TikTokIcon className="h-4 w-4" />,
  Instagram: <InstagramIcon className="h-4 w-4" />,
  YouTube: <YouTubeIcon className="h-4 w-4" />,
  Snapchat: <SnapchatIcon className="h-4 w-4" />,
  Leaderboards: <TrendingUp className="h-4 w-4" />,
  Marketing: <Megaphone className="h-4 w-4" />,
  SEO: <Search className="h-4 w-4" />,
  Productivity: <Zap className="h-4 w-4" />,
  Agents: <Bot className="h-4 w-4" />,
  Developer: <Code className="h-4 w-4" />,
  Crypto: <Bitcoin className="h-4 w-4" />,
  Other: <MoreHorizontal className="h-4 w-4" />,
  Explore: <Compass className="h-4 w-4" />,
};

export const CATEGORIES: Category[] = [
  'All',
  'TikTok',
  'Instagram',
  'YouTube',
  'Snapchat',
  'Leaderboards',
  'Marketing',
  'SEO',
  'Productivity',
  'Agents',
  'Developer',
  'Crypto',
  'Other',
  'Explore',
];
