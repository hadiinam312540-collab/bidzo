import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  X,
  ExternalLink,
  Sparkles,
  ShieldCheck,
  CheckCircle2,
  Clock,
  ArrowRight,
  Flame,
  Volume2,
  VolumeX,
  Zap,
} from 'lucide-react';

export interface SponsorAd {
  id: string;
  name: string;
  tagline: string;
  description: string;
  category: string;
  badge: string;
  logoUrl: string;
  websiteUrl: string;
  accentColor: string;
  features: string[];
  callToAction: string;
}

export const SPONSOR_ADS: SponsorAd[] = [
  {
    id: 'supabase',
    name: 'Supabase',
    tagline: 'The Open Source Firebase Alternative',
    description:
      'Build production web applications in a weekend. Instant Postgres database, realtime subscriptions, authentication, storage, and serverless edge functions.',
    category: 'Developer Platform',
    badge: 'Official Cloud Partner',
    logoUrl: 'https://www.google.com/s2/favicons?domain=supabase.com&sz=128',
    websiteUrl: 'https://supabase.com',
    accentColor: '#3ECF8E',
    features: ['Instant Postgres DB', 'Real-time WebSockets', 'Row-Level Security'],
    callToAction: 'Start Free on Supabase',
  },
  {
    id: 'cursor',
    name: 'Cursor AI',
    tagline: 'The AI-First Code Editor for Extraordinary Builders',
    description:
      'Built to make software engineers 10x more productive. Multi-file edits, natural language codebase search, and instant terminal command execution.',
    category: 'AI Developer Tool',
    badge: 'Featured Sponsor',
    logoUrl: 'https://www.google.com/s2/favicons?domain=cursor.com&sz=128',
    websiteUrl: 'https://cursor.com',
    accentColor: '#3B82F6',
    features: ['Multi-file Composer', 'Predictive Tab', 'Local Code Privacy'],
    callToAction: 'Download Cursor for Free',
  },
  {
    id: 'resend',
    name: 'Resend',
    tagline: 'Email for Developers — Never Hit Spam Folders Again',
    description:
      'The modern transactional email API designed specifically for high-growth SaaS applications. Built with React Email and instant deliverability.',
    category: 'Infrastructure',
    badge: 'Verified Sponsor',
    logoUrl: 'https://www.google.com/s2/favicons?domain=resend.com&sz=128',
    websiteUrl: 'https://resend.com',
    accentColor: '#10B981',
    features: ['99.9% Deliverability', 'React Email Components', 'Global CDN'],
    callToAction: 'Send Free Emails',
  },
  {
    id: 'vercel',
    name: 'Vercel',
    tagline: 'Develop. Preview. Ship. The Modern Frontend Cloud.',
    description:
      'Deploy full-stack web applications effortlessly with automatic CI/CD, global edge networks, serverless functions, and zero-configuration scaling.',
    category: 'Cloud Deployment',
    badge: 'Featured Cloud',
    logoUrl: 'https://www.google.com/s2/favicons?domain=vercel.com&sz=128',
    websiteUrl: 'https://vercel.com',
    accentColor: '#000000',
    features: ['Instant Deployments', 'Global Edge CDN', 'DDoS Protection'],
    callToAction: 'Deploy with Vercel',
  },
  {
    id: 'posthog',
    name: 'PostHog',
    tagline: 'The All-in-One Developer Analytics Suite',
    description:
      'Everything engineers need: Product analytics, session replays, feature flags, A/B testing, and user surveys in a single developer platform.',
    category: 'Product Analytics',
    badge: 'Partner Sponsor',
    logoUrl: 'https://www.google.com/s2/favicons?domain=posthog.com&sz=128',
    websiteUrl: 'https://posthog.com',
    accentColor: '#F59E0B',
    features: ['Session Recording', 'Feature Flags', 'Free 1M Events/mo'],
    callToAction: 'Explore PostHog',
  },
];

interface RewardedAdModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAdCompleted: () => void;
  targetProduct: string;
  bidPoints: number;
}

export const RewardedAdModal: React.FC<RewardedAdModalProps> = ({
  isOpen,
  onClose,
  onAdCompleted,
  targetProduct,
  bidPoints,
}) => {
  const AD_DURATION = 5; // 5 seconds rewarded duration
  const [timeLeft, setTimeLeft] = useState<number>(AD_DURATION);
  const [isCompleted, setIsCompleted] = useState<boolean>(false);
  const [activeAdIndex, setActiveAdIndex] = useState<number>(0);
  const [isInteracted, setIsInteracted] = useState<boolean>(false);

  // Pick a sponsor or rotate whenever modal opens
  useEffect(() => {
    if (isOpen) {
      const randomIndex = Math.floor(Math.random() * SPONSOR_ADS.length);
      setActiveAdIndex(randomIndex);
      setTimeLeft(AD_DURATION);
      setIsCompleted(false);
      setIsInteracted(false);
    }
  }, [isOpen]);

  // Countdown timer
  useEffect(() => {
    if (!isOpen || isCompleted) return;

    if (timeLeft <= 0) {
      setIsCompleted(true);
      return;
    }

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          setIsCompleted(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isOpen, timeLeft, isCompleted]);

  if (!isOpen) return null;

  const currentAd = SPONSOR_ADS[activeAdIndex] || SPONSOR_ADS[0];
  const progressPercent = Math.min(100, Math.round(((AD_DURATION - timeLeft) / AD_DURATION) * 100));

  const handleClaimReward = () => {
    onAdCompleted();
  };

  const handleVisitSponsor = () => {
    setIsInteracted(true);
    // User visiting sponsor instantly completes reward early as a bonus
    setIsCompleted(true);
    setTimeLeft(0);
    window.open(currentAd.websiteUrl, '_blank', 'noopener,noreferrer');
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 font-sans">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.15 }}
          onClick={() => {
            if (isCompleted) {
              onClose();
            }
          }}
          className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm transform-gpu"
        />

        {/* Modal Card */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 12 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 12 }}
          transition={{ type: 'spring', duration: 0.25, bounce: 0 }}
          className="relative z-10 w-full max-w-lg overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-2xl text-slate-900 transform-gpu will-change-transform"
        >
          {/* Header Bar */}
          <div className="flex items-center justify-between border-b border-slate-100 bg-slate-50/80 px-4 py-3 sm:px-5">
            <div className="flex items-center gap-2">
              <span className="flex h-6 w-6 items-center justify-center rounded-lg bg-blue-600 text-white shadow-2xs">
                <Sparkles className="h-3.5 w-3.5" />
              </span>
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-blue-600 block">
                  Rewarded Sponsor Showcase
                </span>
                <span className="text-xs font-semibold text-slate-800">
                  Watch to unlock free rank for &ldquo;{targetProduct || 'Your Product'}&rdquo;
                </span>
              </div>
            </div>

            {/* Countdown / Status badge */}
            <div className="flex items-center gap-2">
              {isCompleted ? (
                <div className="inline-flex items-center gap-1 rounded-full bg-emerald-100 px-2.5 py-1 text-[11px] font-bold text-emerald-800 shadow-2xs animate-in fade-in zoom-in-90">
                  <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600" />
                  <span>Reward Ready</span>
                </div>
              ) : (
                <div className="inline-flex items-center gap-1 rounded-full border border-blue-200 bg-blue-50 px-2.5 py-1 text-[11px] font-mono font-bold text-blue-700">
                  <Clock className="h-3.5 w-3.5 text-blue-600 animate-spin" style={{ animationDuration: '3s' }} />
                  <span>{timeLeft}s remaining</span>
                </div>
              )}

              {/* Close Button (accessible once completed or available to exit) */}
              <button
                type="button"
                onClick={onClose}
                className="rounded-full p-1 text-slate-400 hover:bg-slate-200 hover:text-slate-800 transition-colors ml-1"
                title="Cancel & Close"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          </div>

          {/* Progress bar */}
          <div className="h-1 w-full bg-slate-100 overflow-hidden">
            <motion.div
              className="h-full bg-blue-600"
              initial={{ width: '0%' }}
              animate={{ width: `${progressPercent}%` }}
              transition={{ ease: 'linear', duration: 0.2 }}
            />
          </div>

          {/* Sponsored Creative Body */}
          <div className="p-5 sm:p-6 space-y-4">
            {/* Sponsor Header Card */}
            <div className="flex items-start justify-between gap-3 rounded-xl border border-slate-200/80 bg-gradient-to-br from-slate-50 via-white to-blue-50/30 p-4 shadow-xs">
              <div className="flex items-center gap-3">
                <div className="relative flex h-14 w-14 shrink-0 items-center justify-center rounded-xl border border-slate-200 bg-white p-2 shadow-2xs">
                  <img
                    src={currentAd.logoUrl}
                    alt={`${currentAd.name} logo`}
                    className="h-9 w-9 object-contain"
                  />
                  <div
                    title="Verified Sponsor"
                    className="absolute -bottom-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-blue-600 text-white shadow-2xs ring-2 ring-white"
                  >
                    <ShieldCheck className="h-2.5 w-2.5" />
                  </div>
                </div>

                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="font-heading text-base font-bold text-slate-900">
                      {currentAd.name}
                    </h4>
                    <span className="rounded-md border border-slate-200 bg-white px-1.5 py-0.5 text-[10px] font-semibold text-slate-600">
                      {currentAd.category}
                    </span>
                  </div>
                  <p className="text-xs font-medium text-blue-600 mt-0.5">
                    {currentAd.tagline}
                  </p>
                </div>
              </div>

              <span className="hidden sm:inline-block rounded-full bg-emerald-50 border border-emerald-200 px-2 py-0.5 text-[10px] font-semibold text-emerald-700 whitespace-nowrap">
                {currentAd.badge}
              </span>
            </div>

            {/* Sponsor Description */}
            <div className="rounded-xl bg-slate-50 border border-slate-200/70 p-3.5 text-xs text-slate-700 leading-relaxed">
              <p>{currentAd.description}</p>

              {/* Bullet Features */}
              <div className="mt-3 flex flex-wrap gap-2 pt-2 border-t border-slate-200/60">
                {currentAd.features.map((feat, idx) => (
                  <span
                    key={idx}
                    className="inline-flex items-center gap-1 rounded-md bg-white border border-slate-200 px-2 py-0.5 text-[11px] font-medium text-slate-700 shadow-2xs"
                  >
                    <CheckCircle2 className="h-3 w-3 text-emerald-600" />
                    <span>{feat}</span>
                  </span>
                ))}
              </div>
            </div>

            {/* Visit Sponsor Interactive Card */}
            <div className="flex items-center justify-between rounded-xl border border-blue-100 bg-blue-50/50 px-3.5 py-2.5">
              <div className="text-xs">
                <span className="font-semibold text-slate-900 block">
                  Support Our Sponsor
                </span>
                <span className="text-[11px] text-slate-500">
                  Visiting the sponsor instantly verifies your rewarded rank unlock.
                </span>
              </div>
              <button
                type="button"
                onClick={handleVisitSponsor}
                className="flex items-center gap-1 rounded-lg border border-blue-200 bg-white px-3 py-1.5 text-xs font-semibold text-blue-600 hover:bg-blue-50 transition-colors shadow-2xs cursor-pointer shrink-0"
              >
                <span>{currentAd.callToAction}</span>
                <ExternalLink className="h-3 w-3" />
              </button>
            </div>
          </div>

          {/* Footer Action Bar */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 border-t border-slate-200 bg-slate-50 px-5 py-3.5">
            <div className="text-xs text-slate-500 text-center sm:text-left">
              {isCompleted ? (
                <span className="font-medium text-emerald-700 flex items-center gap-1.5">
                  <CheckCircle2 className="h-4 w-4 text-emerald-600" />
                  <span>Sponsor reward unlocked! Your bid is 100% free.</span>
                </span>
              ) : (
                <span>
                  Please watch for <strong className="text-slate-800">{timeLeft} seconds</strong> to claim your free rank.
                </span>
              )}
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <button
                type="button"
                onClick={onClose}
                className="w-1/2 sm:w-auto rounded-xl border border-slate-200 bg-white px-3.5 py-2 text-xs font-medium text-slate-600 hover:bg-slate-100 transition-colors"
              >
                Cancel
              </button>

              <button
                type="button"
                disabled={!isCompleted}
                onClick={handleClaimReward}
                className={`w-1/2 sm:w-auto flex items-center justify-center gap-1.5 rounded-xl px-5 py-2 text-xs font-bold transition-all shadow-xs transform-gpu ${
                  isCompleted
                    ? 'bg-blue-600 text-white hover:bg-blue-700 cursor-pointer active:scale-95 shadow-blue-600/25 ring-2 ring-blue-500/20'
                    : 'bg-slate-200 text-slate-400 cursor-not-allowed opacity-75'
                }`}
              >
                <Zap className="h-3.5 w-3.5 fill-current" />
                <span>Publish Free Bid Now</span>
                <ArrowRight className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
export default RewardedAdModal;
