import React, { useState, useRef, useEffect } from 'react';
import { ChevronDown, Check } from 'lucide-react';
import { Category } from '../types';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';
import { CATEGORIES, CATEGORY_ICON_MAP } from './ui/CategoryConfig';

interface CategoryBarProps {
  selectedCategory: Category;
  onSelectCategory: (category: Category) => void;
  categoryCounts?: Record<string, number>;
}

export const CategoryBar: React.FC<CategoryBarProps> = ({
  selectedCategory,
  onSelectCategory,
  categoryCounts = {},
}) => {
  const [categoryBarRef, isCategoryBarVisible] = useIntersectionObserver();
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isOpen]);

  const handleToggle = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsOpen((prev) => !prev);
  };

  const totalBidsCount = Object.values(categoryCounts).reduce((acc, curr) => acc + curr, 0);
  const activeCount = selectedCategory === 'All' ? totalBidsCount : categoryCounts[selectedCategory] || 0;

  return (
    <div
      ref={categoryBarRef}
      className={`relative z-30 mx-auto w-full max-w-5xl px-4 sm:px-6 overflow-visible scroll-fade-in ${isCategoryBarVisible ? 'is-visible' : ''}`}
    >
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 pb-3 overflow-visible">
        {/* Parent container with relative positioning */}
        <div className={`relative w-full sm:w-64 ${isOpen ? 'z-[9999]' : 'z-30'}`} ref={dropdownRef}>
          <button
            id="category-filter-dropdown"
            type="button"
            onClick={handleToggle}
            aria-expanded={isOpen}
            aria-haspopup="listbox"
            className="flex w-full items-center justify-between gap-2 rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-xs font-semibold text-slate-900 transition-colors hover:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20 cursor-pointer select-none shadow-2xs"
          >
            <span className="flex items-center gap-2 font-heading truncate">
              {CATEGORY_ICON_MAP[selectedCategory as keyof typeof CATEGORY_ICON_MAP]}
              <span className="truncate">{selectedCategory}</span>
            </span>
            <ChevronDown className={`h-3.5 w-3.5 shrink-0 text-slate-400 transition-transform duration-150 ${isOpen ? 'rotate-180' : ''}`} />
          </button>

          {isOpen && (
            <div
              role="listbox"
              onClick={(e) => e.stopPropagation()}
              className="absolute top-full left-0 w-full z-[9999] bg-white border border-slate-200 rounded-xl shadow-xl max-h-60 overflow-y-auto mt-2 p-1.5 space-y-0.5"
            >
              {CATEGORIES.map((cat) => (
                <button
                  key={cat}
                  type="button"
                  role="option"
                  aria-selected={selectedCategory === cat}
                  onClick={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    onSelectCategory(cat);
                    setIsOpen(false);
                  }}
                  className={`flex w-full items-center gap-2.5 rounded-xl px-3 py-2 text-xs font-medium transition-colors cursor-pointer ${
                    selectedCategory === cat
                      ? 'bg-blue-600 text-white shadow-xs font-semibold'
                      : 'text-slate-700 hover:bg-slate-100 hover:text-slate-900'
                  }`}
                >
                  <span className={selectedCategory === cat ? 'text-white' : 'text-slate-500'}>
                    {CATEGORY_ICON_MAP[cat as keyof typeof CATEGORY_ICON_MAP]}
                  </span>
                  <span className="truncate">{cat}</span>
                  {selectedCategory === cat && <Check className="h-3.5 w-3.5 ml-auto shrink-0" />}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Category active count badge */}
        <div className="hidden sm:flex items-center gap-1.5 text-xs text-slate-500 font-sans">
          <span className="font-semibold text-slate-800">{activeCount}</span>
          <span>bids in</span>
          <span className="font-semibold text-blue-600">{selectedCategory}</span>
        </div>
      </div>
    </div>
  );
};

export default CategoryBar;
